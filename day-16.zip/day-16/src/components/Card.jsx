const Card = () => {
    return(
    <div className="grid"></div>
    );
};

export default Card;