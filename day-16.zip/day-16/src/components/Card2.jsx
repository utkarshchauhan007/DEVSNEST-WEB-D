const Card2 = () => {
    return(
    <div className="grid2"></div>
    );
};

export default Card2;