// import { directive } from "@babel/types";
import Card from "./components/Card";
import Card2 from "./components/Card2";
import Card3 from "./components/Card3"
import "./style.css";


function App(){
    return(
        <div className="App">
         <div className="Meme">
            <Card3 />
        </div>
        <div className="Appinner">
        <div className="first first1">
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        </div>
        <div className="second second1">
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        </div>
        <div className="first first2">
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        </div>
        <div className="second second2">
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        </div>
        <div className="first first3">
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        </div>
        <div className="second second3">
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        </div>
        <div className="first first4">
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        </div>
        <div className="second second4">
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        <Card2 />
        <Card />
        </div>
        
        </div>
        </div>
       
    );
}

export default App;